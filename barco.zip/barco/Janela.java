package barco;

import javax.swing.JFrame;

public class Janela extends JFrame{

    public Janela() {
        this.setTitle("Algoritmo DDA");
        this.setSize(400, 400);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        
        this.add(new Desenho());
    }
    
}
